N=[20];
D=[1 5 4];
TF1=tf(N,D);
step(TF1);
TF2= feedback (TF1, 1, -1);
step(TF2);