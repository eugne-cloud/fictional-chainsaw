t=out.sys(:, 1);
r= out.res(:, 2);
